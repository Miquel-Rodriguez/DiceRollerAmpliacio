package cat.itb.diceroller;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button rollButton;
    Button button_res;
    Button button_dice1;
    Button button_dice2;

    ImageView imageView;
    ImageView imageView2;
    static final int [] imatgesRoll= {R.drawable.dice_1,R.drawable.dice_2,R.drawable.dice_3,R.drawable.dice_4,R.drawable.dice_5,R.drawable.dice_6};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button_dice1 = findViewById(R.id.button_dice1);
        button_dice2 = findViewById(R.id.button_dice2);
        button_res = findViewById(R.id.button_res);
        rollButton = findViewById(R.id.roll_button);
        imageView = findViewById(R.id.image);
        imageView2 = findViewById(R.id.imageTwo);


        inici();


        button_dice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                roll1();
            }
        });

        button_dice2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                roll2();
            }
        });

        rollButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rollButton.setText("Dice Rolled");

                int resultat = roll1();
                if (resultat == roll2() && resultat == 6) {
                    Toast toast = Toast.makeText(MainActivity.this, "JACKPOT!!", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 0);
                    toast.show();
                }

            }
        });
        button_res.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inici();
            }
        });
    }

    private void inici() {
        imageView.setImageResource(R.drawable.empty_dice);
        imageView2.setImageResource(R.drawable.empty_dice);
        rollButton.setText("Roll the dice");
    }

    private  int roll1(){
        int result1 = (int) (Math.random() * 5) + 1;
        imageView.setImageResource(imatgesRoll[result1]);
        return result1;
    }

    private  int roll2(){
        int result2 = (int) (Math.random() * 5) + 1;
        imageView2.setImageResource(imatgesRoll[result2]);
        return result2;
    }

}

